setTimeout(function() {
  setScreen("screen2");
}, 1000);
onEvent("button1", "click", function( ) {
  setScreen("area");
});
onEvent("button2", "click", function( ) {
  setScreen("perimeter");
});
onEvent("button3", "click", function( ) {
  setScreen("volume");
});
onEvent("button4", "click", function( ) {
  setScreen("squares");
});
onEvent("button5", "click", function( ) {
  setScreen("cubes");
});
onEvent("image3", "click", function( ) {
  setImageURL("image1", "assets/area-2.png");
});
// back buttons
onEvent("image2", "click", function( ) {
  setScreen("screen2");
});
onEvent("image6", "click", function( ) {
  setScreen("screen2");
});
onEvent("image9", "click", function( ) {
  setScreen("screen2");
});
onEvent("image11", "click", function( ) {
  setScreen("screen2");
});
onEvent("image13", "click", function( ) {
  setScreen("screen2");
});
